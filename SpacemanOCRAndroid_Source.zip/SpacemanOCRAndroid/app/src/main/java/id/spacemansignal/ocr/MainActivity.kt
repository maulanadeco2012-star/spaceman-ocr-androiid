package id.spacemansignal.ocr

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.nio.ByteBuffer
import java.util.Locale
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private val requestCapture = 4102
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var lastOcrAt = 0L
    private var candidate: String? = null
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val history = mutableListOf<Double>()
    private lateinit var status: TextView
    private lateinit var detected: TextView
    private lateinit var manual: EditText
    private lateinit var historyView: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var confirmButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            setBackgroundColor(0xFF0A1021.toInt())
        }
        fun addText(value: String, size: Float, color: Int = 0xFFF3F6FF.toInt()) =
            TextView(this).apply {
                text = value; textSize = size; setTextColor(color); setPadding(0, 8, 0, 8)
                root.addView(this, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
        addText("🚀 Spaceman OCR Signal", 26f, 0xFF58DDF5.toInt())
        addText("OCR layar Android. Selalu periksa angka sebelum menyimpan.", 14f, 0xFFB9C5DE.toInt())
        status = addText("Status: belum berbagi layar", 16f, 0xFF58DDF5.toInt())
        startButton = Button(this).apply { text = "Mulai tangkap layar"; setOnClickListener { requestCapture() } }
        root.addView(startButton)
        stopButton = Button(this).apply { text = "Hentikan tangkapan"; isEnabled = false; setOnClickListener { stopCapture() } }
        root.addView(stopButton)
        addText("Kandidat OCR", 18f)
        detected = addText("Belum ada angka terdeteksi", 21f, 0xFF58DDF5.toInt())
        confirmButton = Button(this).apply {
            text = "Konfirmasi & simpan angka OCR"; isEnabled = false
            setOnClickListener { candidate?.let { saveValue(it) } }
        }
        root.addView(confirmButton)
        addText("Input manual (contoh 1.75)", 15f)
        manual = EditText(this).apply {
            hint = "Multiplier"; setSingleLine(true); setTextColor(-1); setHintTextColor(0xFF8996B2.toInt())
            setBackgroundColor(0xFF1A2540.toInt())
        }
        root.addView(manual)
        root.addView(Button(this).apply {
            text = "Simpan input manual"
            setOnClickListener { saveValue(manual.text.toString()) }
        })
        addText("Riwayat & status sinyal", 18f)
        historyView = addText("Riwayat masih kosong. Sinyal: TUNGGU.", 14f)
        root.addView(Button(this).apply { text = "Hapus riwayat"; setOnClickListener { history.clear(); updateHistory() } })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestCapture() {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestCapture) return
        if (resultCode != Activity.RESULT_OK || data == null) {
            status.text = "Status: izin dibatalkan"; return
        }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        startProjection()
    }

    private fun startProjection() {
        val dm = resources.displayMetrics
        val w = max(1, dm.widthPixels); val h = max(1, dm.heightPixels)
        thread = HandlerThread("SpacemanOCR").also { it.start() }
        handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val now = System.currentTimeMillis()
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (now - lastOcrAt < 2000) { image.close(); return@setOnImageAvailableListener }
            lastOcrAt = now
            val bmp = toBitmap(image); image.close()
            if (bmp != null) recognize(bmp)
        }, handler)
        virtualDisplay = projection?.createVirtualDisplay(
            "SpacemanOCR", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler
        )
        status.text = "Status: tangkapan aktif. Angka harus dikonfirmasi."
        startButton.isEnabled = false; stopButton.isEnabled = true
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { runOnUiThread { stopCapture() } }
        }, handler)
    }

    private fun toBitmap(image: Image): Bitmap? = try {
        val p = image.planes[0]; val buffer: ByteBuffer = p.buffer
        val paddedWidth = image.width + (p.rowStride - p.pixelStride * image.width) / p.pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
    } catch (_: Exception) { null }

    private fun recognize(bitmap: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                val rx = Regex("""(?<![\d.])(\d{1,3}(?:[.,]\d{1,2})?)\s*[xX×]?""")
                val numbers = rx.findAll(result.text).mapNotNull {
                    it.groupValues[1].replace(",", ".").toDoubleOrNull()
                }.filter { it >= 1.0 && it <= 10000.0 }.toList()
                runOnUiThread {
                    val n = numbers.firstOrNull()
                    if (n == null) {
                        candidate = null; confirmButton.isEnabled = false
                        detected.text = "Belum ada angka yang cocok. Gunakan input manual jika perlu."
                    } else {
                        candidate = String.format(Locale.US, "%.2f", n)
                        detected.text = "Terdeteksi: ${candidate}x\nPeriksa apakah benar multiplier game."
                        confirmButton.isEnabled = true
                    }
                }
            }.addOnFailureListener {
                runOnUiThread { detected.text = "OCR gagal. Coba lagi atau input manual." }
            }
    }

    private fun saveValue(raw: String) {
        val n = raw.trim().lowercase(Locale.US).replace("x", "").replace(",", ".").toDoubleOrNull()
        if (n == null || n < 1.0 || n > 10000.0) {
            Toast.makeText(this, "Multiplier tidak valid; contoh 1.75", Toast.LENGTH_SHORT).show(); return
        }
        history.add(0, n); candidate = null; confirmButton.isEnabled = false
        detected.text = "Belum ada angka terdeteksi"; manual.text.clear(); updateHistory()
    }

    private fun updateHistory() {
        historyView.text = if (history.isEmpty()) "Riwayat masih kosong. Sinyal: TUNGGU." else {
            val rows = history.take(50).mapIndexed { i, v -> "${i+1}. ${String.format(Locale.US, "%.2f", v)}x" }.joinToString("\n")
            rows + "\n\nSinyal: TUNGGU — riwayat pendek tidak dapat memastikan hasil berikutnya."
        }
    }

    private fun stopCapture() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Exception) {}
        reader = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        try { thread?.quitSafely() } catch (_: Exception) {}
        thread = null; handler = null
        if (::status.isInitialized) status.text = "Status: tangkapan berhenti"
        if (::startButton.isInitialized) startButton.isEnabled = true
        if (::stopButton.isInitialized) stopButton.isEnabled = false
    }

    override fun onDestroy() {
        stopCapture()
        recognizer.close()
        super.onDestroy()
    }
}
